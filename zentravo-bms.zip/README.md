# Zentravo BMS — Business Management System

> All-in-one SaaS platform for Sri Lankan retail businesses

## Overview

Zentravo BMS is a production-grade, multi-tenant business management platform built specifically for Sri Lankan retail businesses. It supports POS, Inventory, Accounting, Warranty, Service/Repair, E-Commerce, CRM, Loyalty, Marketing, and AI Business Assistant.

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 14 (App Router) |
| Language | TypeScript (strict) |
| Styling | Tailwind CSS v4 + shadcn/ui |
| ORM | Prisma v7 |
| Database | Neon PostgreSQL |
| Auth | NextAuth v5 (Auth.js) |
| Forms | React Hook Form + Zod |
| Data Fetching | TanStack Query v5 |
| Charts | Recharts |
| File Upload | Cloudinary |
| State | Zustand |
| AI | OpenAI (provider abstracted) |

## Quick Start

### Prerequisites
- Node.js 20+
- npm

### Setup

```bash
# Clone and enter directory
cd "e:\Zentravo Lab\Business Management System\zentravo-bms"

# Install dependencies
npm install

# Setup environment
cp .env.example .env.local
# Edit .env.local with your credentials

# Push database schema
npx prisma db push

# Seed demo data
npm run db:seed

# Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Demo Credentials

After seeding, use these to log in:

| Role | Email | Password |
|---|---|---|
| Owner | owner@example.com | Demo@2026 |
| Manager | manager@example.com | Demo@2026 |
| Cashier | cashier@example.com | Demo@2026 |
| Accountant | accountant@example.com | Demo@2026 |
| Technician | technician@example.com | Demo@2026 |

## Project Structure

```
src/
├── app/
│   ├── (auth)/          # Login, register
│   ├── (dashboard)/     # Business dashboard
│   ├── (customer)/      # Customer portal
│   ├── (store)/         # Public online storefront
│   ├── (super-admin)/   # Platform admin
│   ├── onboarding/      # Business onboarding wizard
│   └── api/             # API routes
├── components/
│   ├── ui/              # shadcn primitives
│   ├── layout/          # Sidebar, header
│   └── dashboard/       # Dashboard components
├── lib/
│   ├── auth.ts          # NextAuth config
│   ├── db.ts            # Prisma client
│   ├── permissions.ts   # RBAC system
│   └── utils.ts         # Utilities
├── schemas/             # Zod validation schemas
├── services/            # Business logic layer
└── types/               # TypeScript types
prisma/
├── schema.prisma        # Database schema (50+ models)
└── seed.ts              # Demo data seed
```

## Database Commands

```bash
npm run db:push      # Push schema to database (no migrations)
npm run db:migrate   # Create and apply migrations
npm run db:seed      # Seed demo data
npm run db:studio    # Open Prisma Studio
npm run db:reset     # Reset database (DANGER)
```

## Architecture

See [ARCHITECTURE.md](./docs/ARCHITECTURE.md) for full system design.

## Security

- Passwords: bcrypt (cost 12)
- OTP: 6-digit, 5-minute expiry, rate-limited
- Sessions: NextAuth JWT
- Tenant isolation: Server-side businessId enforcement
- Input validation: Zod schemas on all endpoints

## License

Private — All rights reserved. © 2026 Zentravo.
