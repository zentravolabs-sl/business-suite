import { auth } from "@/lib/auth";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// Routes that require authentication
const protectedPrefixes = ["/dashboard", "/onboarding", "/super-admin"];
// Routes that are only for unauthenticated users
const authRoutes = ["/login", "/register"];
// Public routes that never need auth
const publicRoutes = ["/", "/store", "/verify-warranty", "/warranty/verify", "/api/webhooks", "/portal"];

export default auth(function middleware(req: NextRequest & { auth: unknown }) {
  const { nextUrl, auth: session } = req as NextRequest & { auth: { user?: { id: string } } | null };
  const isLoggedIn = !!(req as unknown as { auth: { user?: unknown } | null }).auth?.user;
  const pathname = nextUrl.pathname;

  // Check if route is public
  const isPublic = publicRoutes.some(
    (route) => pathname.startsWith(route) || pathname === route
  );
  if (isPublic) return NextResponse.next();

  // API routes - let them handle their own auth
  if (pathname.startsWith("/api/")) return NextResponse.next();

  // Auth routes - redirect to dashboard if already logged in
  const isAuthRoute = authRoutes.some((route) => pathname.startsWith(route));
  if (isAuthRoute) {
    if (isLoggedIn) {
      return NextResponse.redirect(new URL("/dashboard", nextUrl));
    }
    return NextResponse.next();
  }

  // Protected routes - redirect to login if not logged in
  const isProtected = protectedPrefixes.some((prefix) =>
    pathname.startsWith(prefix)
  );
  if (isProtected && !isLoggedIn) {
    const loginUrl = new URL("/login", nextUrl);
    loginUrl.searchParams.set("callbackUrl", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Super admin protection
  if (pathname.startsWith("/super-admin")) {
    // Additional super admin checks handled in layout
    return NextResponse.next();
  }

  return NextResponse.next();
});

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
